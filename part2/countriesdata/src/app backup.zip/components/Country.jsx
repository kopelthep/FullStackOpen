
import { useEffect, useState } from 'react';
import countryService from '../services/countries';

export const Country = ({ countryinfo }) => {
    
    console.log("country comp", countryinfo);
    let country = countryinfo
    const [selectedCountryWeather, setSelectedCountryWeather] = useState(null)
    

    useEffect(() => {
        const capital = country?.capital?.[0]

        if (!capital) {
            setSelectedCountryWeather(null)
            return
        }

        let cancelled = false

        try {
            const weatherRequest = countryService.getCityWeather(capital)

            if (!weatherRequest) {
                setSelectedCountryWeather(null)
                return
            }

            weatherRequest
                .then(response => {
                    if (!cancelled) {
                        setSelectedCountryWeather(response)
                    }
                })
                .catch(error => {
                    if (!cancelled) {
                        console.error('weather fetch failed', error)
                        setSelectedCountryWeather(null)
                    }
                })
        } catch (error) {
            if (!cancelled) {
                console.error('weather request blocked', error)
                setSelectedCountryWeather(null)
            }
        }

        return () => {
            cancelled = true
        }
    }, [country?.capital?.[0]])

    if (country !== null){
        const cityWeather = selectedCountryWeather == null ? {main:{temp:273.15},weather:[{icon:"01d"}]} : selectedCountryWeather
        const image = `https://openweathermap.org/payload/api/media/file/${cityWeather.weather[0].icon}.png`
        
        const transformed = (
            Object.entries(country.languages).map(([key, val]) => [key,val])
        )
        console.log("languages list",transformed)
        return(
            <>
            Placeholder : {country.name.common}
            <h1>
                {country.name.common}
            </h1>
            <div>Capital:{country.capital}</div>
            <div>Area:{country.area}</div>
            <h2>
                Languages
            </h2>
            <ul>
            {transformed.map(([key,language]) => (
                <li key={key}>
                    {language}
                </li>  
            ))}
            </ul>
            <img src={country.coatOfArms.svg} width="200px" height="200px" ></img>
            <h2>
                Weather in {country.capital}:
                {((cityWeather.main.temp) - 273.15).toPrecision(3)}
            <img src={image}></img>
            </h2>
            <div>


            </div>
            </>
        )
    }
    return (
        <></>
    );
};

